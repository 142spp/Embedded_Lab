#include <stdio.h>
#include <stdlib.h>

#include "lcd.h"
#include "misc.h"
#include "stm32f10x.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_tim.h"
#include "touch.h"

uint16_t count = 0;
enum {OFF=0,ON=!OFF};

/* function prototype */
void Delay(void);
void RCC_Configure(void);
void GPIO_Init(void);
void TIM_Configure(void);
void EXTI_Configure(void);
void NVIC_Configure(void);
void TIM_IRQHandler(void);

//---------------------------------------------------------------------------------------------------
void RCC_Configure(void) {
    // Enable 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
    // Enable the TIM2 clock
    RCC_APB1PeriphClockCmd(RCC_APB1ENR_TIM2EN, ENABLE);
}

void GPIO_Configure(void) {
    GPIO_InitTypeDef GPIO_InitStructure;

    /* LED pin setting*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);
}

void TIM_Configure(void) {
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

    TIM_TimeBaseStructure.TIM_Period = 10000;
    TIM_TimeBaseStructure.TIM_Prescaler = 7200;
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
    TIM_Cmd(TIM2, ENABLE);
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
}

void EXTI_Configure(void) {
    EXTI_InitTypeDef EXTI_InitStructure;

    GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource5);
    EXTI_InitStructure.EXTI_Line = EXTI_Line11;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
}

void NVIC_Configure(void) {
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn; // TIM2 interrupt
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;  
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;         
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void TIM2_IRQHandler(void) {
    /*ITStatus*/
    if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET) {
        count++;    // count is incremented;
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    }
}

int color[12] =  // Color Array
    {WHITE, CYAN, BLUE, RED, MAGENTA, LGRAY, GREEN, YELLOW, BROWN, BRRED, GRAY};

void Set_LED(uint16_t& GPIO_Pin, uint16_t& state){
    if(!state) {
        GPIO_SetBits(GPIOD, GPIO_Pin);
        state = ON;
    } else {
        GPIO_ResetBits(GPIOD, GPIO_Pin);
        state = OFF;
    }
}

int main(void) {
    SystemInit();
    RCC_Configure();
    GPIO_Configure();
    TIM_Configure();
    LCD_Init();
    Touch_Configuration();
    EXTI_Configure();
    NVIC_Configure();
    /*--------------------------*/
    char* team_str = "MON_Team02";

    LCD_ShowString(30, 30, team_str, BLUE, WHITE);  // team
    LCD_ShowString(45, 105, "BUT", RED, WHITE);  // Button
    LCD_DrawRectangle(30, 90, 60, 120);

    uint16_t LED1_state = 0;
    uint16_t LED4_state = 0;
    uint16_t doToggling = 0;
    uint16_t precount = count; 

    while (1) {
        if(!T_INT){                    // LCD touch interrupt
            doToggling = !doToggling;  // toggle switch
            count = 0; }

        if(count != precount && doToggling == 1) 
            Set_LED(GPIO_Pin_2,LED1_state);

        if(!(count % 5) && doToggling == 1)
            Set_LED(GPIO_Pin_7,LED4_state);

        precount = count;
    }

    return 0;
}